<!DOCTYPE html>
<html lang="en">
<!--
    * USCM Tactical Terminal — Index Page
    *
    * Description: Landing page for Zachary's JSON assignment.
    *              Displays a USCM terminal boot sequence and links
    *              to the mission report form.
    *
    * Author: Zachary
    * Date: <?php echo date('m/d/y'); ?>
-->
<head>
    <meta charset="UTF-8">
    <title>USCM Terminal — Zachary JSON</title>
    <link rel="stylesheet" href="css/styles.css">
    <style>
        body {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            padding: 24px;
        }
 
        .terminal {
            width: 100%;
            max-width: 700px;
            border: 1px solid var(--green);
            background: var(--black-mid);
            padding: 40px;
            position: relative;
        }
 
        .terminal-bar {
            position: absolute;
            top: 0; left: 0; right: 0;
            background: var(--green-dark);
            border-bottom: 1px solid var(--green);
            padding: 6px 16px;
            display: flex;
            justify-content: space-between;
            font-size: 10px;
            letter-spacing: 3px;
            color: var(--green-dim);
            text-transform: uppercase;
        }
 
        .terminal-content {
            margin-top: 32px;
        }
 
        .boot-line {
            font-size: 12px;
            letter-spacing: 2px;
            color: var(--green-dim);
            margin-bottom: 6px;
            opacity: 0;
            animation: fadeIn 0.1s forwards;
        }
 
        /* Staggered boot sequence lines */
        .boot-line:nth-child(1)  { animation-delay: 0.2s; }
        .boot-line:nth-child(2)  { animation-delay: 0.5s; }
        .boot-line:nth-child(3)  { animation-delay: 0.8s; }
        .boot-line:nth-child(4)  { animation-delay: 1.1s; }
        .boot-line:nth-child(5)  { animation-delay: 1.4s; }
        .boot-line:nth-child(6)  { animation-delay: 1.7s; }
        .boot-line:nth-child(7)  { animation-delay: 2.0s; }
        .boot-line:nth-child(8)  { animation-delay: 2.3s; }
        .boot-line:nth-child(9)  { animation-delay: 2.6s; }
        .boot-line:nth-child(10) { animation-delay: 2.9s; }
 
        @keyframes fadeIn {
            to { opacity: 1; }
        }
 
        .boot-ok   { color: var(--green); }
        .boot-warn { color: #ffaa00; }
        .boot-err  { color: var(--red); }
 
        .divider {
            border: none;
            border-top: 1px solid var(--green-dark);
            margin: 24px 0;
            opacity: 0;
            animation: fadeIn 0.1s forwards;
            animation-delay: 3.1s;
        }
 
        .main-title {
            font-size: 26px;
            letter-spacing: 6px;
            text-transform: uppercase;
            color: var(--green);
            margin-bottom: 6px;
            opacity: 0;
            animation: fadeIn 0.3s forwards;
            animation-delay: 3.3s;
        }
 
        .main-subtitle {
            font-size: 11px;
            letter-spacing: 3px;
            color: var(--green-dim);
            text-transform: uppercase;
            margin-bottom: 32px;
            opacity: 0;
            animation: fadeIn 0.3s forwards;
            animation-delay: 3.5s;
        }
 
        .menu {
            opacity: 0;
            animation: fadeIn 0.3s forwards;
            animation-delay: 3.7s;
        }
 
        .menu-item {
            display: flex;
            align-items: center;
            gap: 16px;
            padding: 14px 0;
            border-bottom: 1px solid var(--green-dark);
            text-decoration: none;
            transition: all 0.15s;
        }
 
        .menu-item:last-child { border-bottom: none; }
 
        .menu-item:hover {
            padding-left: 10px;
            text-decoration: none;
        }
 
        .menu-item:hover .menu-arrow { color: var(--green); }
        .menu-item:hover .menu-label { color: #fff; }
 
        .menu-arrow {
            font-size: 14px;
            color: var(--green-dim);
            transition: color 0.15s;
            min-width: 16px;
        }
 
        .menu-label {
            font-size: 13px;
            letter-spacing: 3px;
            text-transform: uppercase;
            color: var(--green);
            transition: color 0.15s;
        }
 
        .menu-desc {
            font-size: 10px;
            letter-spacing: 2px;
            color: var(--green-dim);
            text-transform: uppercase;
            margin-left: auto;
        }
 
        .footer-text {
            margin-top: 32px;
            font-size: 10px;
            letter-spacing: 2px;
            color: var(--green-dim);
            text-transform: uppercase;
            text-align: center;
            opacity: 0;
            animation: fadeIn 0.3s forwards;
            animation-delay: 4.0s;
        }
    </style>
</head>
<body>
 
<div class="terminal">
 
    <!-- Terminal title bar -->
    <div class="terminal-bar">
        <span>USCM // WEYLAND-YUTANI CORP</span>
        <span class="blink">SYS_ONLINE</span>
    </div>
 
    <div class="terminal-content">
 
        <!-- Boot sequence -->
        <div class="boot-line">&gt; INITIALIZING USCM TACTICAL TERMINAL v4.2.1...</div>
        <div class="boot-line">&gt; LOADING KERNEL...................................................<span class="boot-ok"> OK</span></div>
        <div class="boot-line">&gt; CHECKING MEMORY BANKS...........................................<span class="boot-ok"> OK</span></div>
        <div class="boot-line">&gt; ESTABLISHING UPLINK TO USS SULACO..............................<span class="boot-ok"> OK</span></div>
        <div class="boot-line">&gt; AUTHENTICATING CREDENTIALS....................................<span class="boot-ok"> OK</span></div>
        <div class="boot-line">&gt; LOADING MISSION DATABASE.......................................<span class="boot-ok"> OK</span></div>
        <div class="boot-line">&gt; SCANNING FOR HOSTILE SIGNATURES...............................<span class="boot-warn"> 1 DETECTED</span></div>
        <div class="boot-line">&gt; INITIALIZING JSON ENCODER......................................<span class="boot-ok"> OK</span></div>
        <div class="boot-line">&gt; BIOWEAPON CONTAINMENT PROTOCOL................................<span class="boot-err"> BREACHED</span></div>
        <div class="boot-line">&gt; SYSTEM READY. PROCEED WITH CAUTION.</div>
 
        <hr class="divider">
 
        <div class="main-title">USCM Tactical DB</div>
        <div class="main-subtitle">Field Debrief &amp; Mission Reporting System &mdash; Zachary JSON</div>
 
        <div class="menu">
            <a href="pages/ZacharyJSON.php" class="menu-item">
                <span class="menu-arrow">&gt;</span>
                <span class="menu-label">Submit Mission Report</span>
                <span class="menu-desc">JSON Encode &amp; Transmit</span>
            </a>
        </div>
 
        <div class="footer-text">
            Weyland-Yutani Corp &mdash; Building Better Worlds &mdash; All transmissions logged &amp; monitored
        </div>
 
    </div>
</div>
 
</body>
</html>