<?php
/**
 * Mission Report — JSON Form
 *
 * Description: Prompts the user to enter mission report data across 8+
 *              fields. On submission, encodes the data using json_encode
 *              and displays it in a formatted terminal-style output.
 *              Returns an error display if validation fails.
 *
 * Author: Zachary
 * Date: <?php echo date('m/d/y'); ?>

 */

$errors      = [];
$jsonOutput  = null;
$formData    = null;
$submitted   = false;

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $submitted = true;

    // ── Sanitize & collect fields ──
    $marine_name      = trim($_POST['marine_name']      ?? '');
    $rank             = trim($_POST['rank']             ?? '');
    $mission_name     = trim($_POST['mission_name']     ?? '');
    $location         = trim($_POST['location']         ?? '');
    $mission_date     = trim($_POST['mission_date']     ?? '');
    $objective        = trim($_POST['objective']        ?? '');
    $outcome          = trim($_POST['outcome']          ?? '');
    $casualties       = trim($_POST['casualties']       ?? '');
    $aliens_neutralized = trim($_POST['aliens_neutralized'] ?? '');
    $notes            = trim($_POST['notes']            ?? '');

    // ── Validation ──
    if (empty($marine_name))        $errors[] = "Reporting marine name is required.";
    if (empty($rank))               $errors[] = "Rank is required.";
    if (empty($mission_name))       $errors[] = "Mission name is required.";
    if (empty($location))           $errors[] = "Location is required.";
    if (empty($mission_date))       $errors[] = "Mission date is required.";
    if (empty($objective))          $errors[] = "Objective is required.";
    if (empty($outcome))            $errors[] = "Outcome is required.";
    if (!is_numeric($casualties))   $errors[] = "Casualties must be a number.";
    if (!is_numeric($aliens_neutralized)) $errors[] = "Aliens neutralized must be a number.";

    // ── Encode if no errors ──
    if (empty($errors)) {
        $formData = [
            "reporting_marine"    => $marine_name,
            "rank"                => $rank,
            "mission_name"        => $mission_name,
            "location"            => $location,
            "mission_date"        => $mission_date,
            "objective"           => $objective,
            "outcome"             => $outcome,
            "casualties"          => (int) $casualties,
            "aliens_neutralized"  => (int) $aliens_neutralized,
            "additional_notes"    => $notes ?: "N/A",
        ];

        $jsonOutput = json_encode($formData, JSON_PRETTY_PRINT);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Zachary JSON — Mission Report</title>
    <link rel="stylesheet" href="../css/styles.css">
    <style>
        .json-output {
            background: var(--black);
            border: 1px solid var(--green);
            padding: 24px;
            margin-top: 24px;
            white-space: pre;
            font-family: var(--font);
            font-size: 13px;
            color: var(--green);
            overflow-x: auto;
            line-height: 1.8;
        }

        .json-key   { color: #00bfff; }
        .json-str   { color: var(--green); }
        .json-num   { color: #ffaa00; }
        .json-label {
            font-size: 10px;
            letter-spacing: 3px;
            color: var(--green-dim);
            text-transform: uppercase;
            margin-bottom: 8px;
        }

        .error-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .error-list li {
            padding: 6px 0;
            color: var(--red);
            font-size: 12px;
            letter-spacing: 2px;
            text-transform: uppercase;
            border-bottom: 1px solid var(--red-dim);
        }

        .error-list li::before {
            content: '> ERR: ';
            color: var(--red);
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .full-width {
            grid-column: 1 / -1;
        }

        textarea {
            resize: vertical;
            min-height: 80px;
        }

        .success-banner {
            font-size: 11px;
            letter-spacing: 3px;
            text-transform: uppercase;
            color: var(--green);
            border-left: 3px solid var(--green);
            background: var(--green-dark);
            padding: 10px 16px;
            margin-bottom: 20px;
        }

        @media (max-width: 600px) {
            .form-row { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>

<div class="index-container" style="max-width: 800px;">

    <div class="index-header">
        <h1>Mission Report</h1>
        <p>USCM Field Debrief System &mdash; Encode &amp; Submit</p>
    </div>

    <?php if ($submitted && !empty($errors)): ?>
        <!-- ── Error Display ── -->
        <div style="border:1px solid var(--red); padding:24px; margin-bottom:24px; position:relative;">
            <div style="position:absolute; top:-10px; left:16px; background:var(--black); padding:0 8px; font-size:10px; letter-spacing:3px; color:var(--red);">> TRANSMISSION_FAILED</div>
            <p style="color:var(--red); letter-spacing:2px; text-transform:uppercase; font-size:12px; margin-bottom:12px;">Report could not be submitted. Correct the following:</p>
            <ul class="error-list">
                <?php foreach ($errors as $error): ?>
                    <li><?= htmlspecialchars($error) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <?php if ($jsonOutput): ?>
        <!-- ── JSON Success Output ── -->
        <div class="success-banner">&gt; Transmission successful — report encoded and logged.</div>

        <div class="json-label">&gt; JSON_OUTPUT // raw encoded data</div>
        <div class="json-output"><?php
            // Syntax-highlight the JSON output
            $highlighted = htmlspecialchars($jsonOutput);
            // Keys (blue)
            $highlighted = preg_replace('/"(\w+)":/', '<span class="json-key">"$1"</span>:', $highlighted);
            // Numbers
            $highlighted = preg_replace('/: (\d+)/', ': <span class="json-num">$1</span>', $highlighted);
            // Strings
            $highlighted = preg_replace('/: "([^"]*)"/', ': <span class="json-str">"$1"</span>', $highlighted);
            echo $highlighted;
        ?></div>

        <br>
        <a href="ZacharyJSON.php"><button>Submit Another Report</button></a>

    <?php else: ?>
        <!-- ── Mission Report Form ── -->
        <div style="border:1px solid var(--green); padding:32px; position:relative;">
            <div style="position:absolute; top:-10px; left:16px; background:var(--black); padding:0 8px; font-size:10px; letter-spacing:3px; color:var(--green-dim);">> USCM_FIELD_REPORT</div>

            <form method="POST">
                <div class="form-row">

                    <div class="form-group">
                        <label for="marine_name">Reporting Marine</label>
                        <input type="text" id="marine_name" name="marine_name"
                               placeholder="e.g. Ellen Ripley"
                               value="<?= htmlspecialchars($_POST['marine_name'] ?? '') ?>">
                    </div>

                    <div class="form-group">
                        <label for="rank">Rank</label>
                        <select id="rank" name="rank">
                            <option value="">-- Select Rank --</option>
                            <?php
                            $ranks = ["Private","Corporal","Sergeant","Lieutenant","Captain","Synthetic","Civilian"];
                            foreach ($ranks as $r) {
                                $sel = (($_POST['rank'] ?? '') === $r) ? 'selected' : '';
                                echo "<option value='$r' $sel>$r</option>";
                            }
                            ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="mission_name">Mission Name</label>
                        <input type="text" id="mission_name" name="mission_name"
                               placeholder="e.g. Operation Clearout"
                               value="<?= htmlspecialchars($_POST['mission_name'] ?? '') ?>">
                    </div>

                    <div class="form-group">
                        <label for="location">Location</label>
                        <input type="text" id="location" name="location"
                               placeholder="e.g. Hadley's Hope, LV-426"
                               value="<?= htmlspecialchars($_POST['location'] ?? '') ?>">
                    </div>

                    <div class="form-group">
                        <label for="mission_date">Mission Date</label>
                        <input type="date" id="mission_date" name="mission_date"
                               value="<?= htmlspecialchars($_POST['mission_date'] ?? '') ?>">
                    </div>

                    <div class="form-group">
                        <label for="outcome">Mission Outcome</label>
                        <select id="outcome" name="outcome">
                            <option value="">-- Select Outcome --</option>
                            <?php
                            $outcomes = ["Success","Partial Success","Failed","Catastrophic Failure","Ongoing"];
                            foreach ($outcomes as $o) {
                                $sel = (($_POST['outcome'] ?? '') === $o) ? 'selected' : '';
                                echo "<option value='$o' $sel>$o</option>";
                            }
                            ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="casualties">Marine Casualties</label>
                        <input type="number" id="casualties" name="casualties"
                               placeholder="0" min="0"
                               value="<?= htmlspecialchars($_POST['casualties'] ?? '') ?>">
                    </div>

                    <div class="form-group">
                        <label for="aliens_neutralized">Aliens Neutralized</label>
                        <input type="number" id="aliens_neutralized" name="aliens_neutralized"
                               placeholder="0" min="0"
                               value="<?= htmlspecialchars($_POST['aliens_neutralized'] ?? '') ?>">
                    </div>

                    <div class="form-group full-width">
                        <label for="objective">Mission Objective</label>
                        <textarea id="objective" name="objective"
                                  placeholder="Describe the mission objective..."><?= htmlspecialchars($_POST['objective'] ?? '') ?></textarea>
                    </div>

                    <div class="form-group full-width">
                        <label for="notes">Additional Notes</label>
                        <textarea id="notes" name="notes"
                                  placeholder="Any additional observations or notes (optional)..."><?= htmlspecialchars($_POST['notes'] ?? '') ?></textarea>
                    </div>

                </div>

                <button type="submit">Transmit Report</button>

            </form>
        </div>

    <?php endif; ?>

</div>

</body>
</html>