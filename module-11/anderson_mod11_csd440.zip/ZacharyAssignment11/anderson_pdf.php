<?php
/**
 * File:        anderson_pdf.php
 * Author:     Zachary
 * Date:       5/18/26
 * Description: Generates a styled PDF report from the
 *              aliens_marines database table. The PDF displays general
 *              background information about the Aliens (1986) Colonial Marines,
 *              followed by a formatted data table that includes a column-header
 *              row and a summary footer row. The document header and footer
 *              repeat on every page.
 *
 * Database:    Tables_in_baseball_01   (connection alias used in course)
 * Table:       aliens_marines
 * Library:     FPDF 1.86 – http://www.fpdf.org/
 *
 * Usage:       Place anderson_pdf.php and fpdf.php on any PHP-enabled web server
 *              in the same directory with font folderin previous folder, then open the file in a browser. The PDF
 *              will render inline. Change Output() second argument to 'D' to
 *              force a download instead.
 *
 * SQL used:
 *   SELECT marine_id, first_name, last_name, marine_rank, kills, deaths, status
 *   FROM   aliens_marines
 *   ORDER  BY marine_id ASC;
 */
define('FPDF_FONTPATH', 'C:/xampp/htdocs/font/');

// ── Require FPDF library ──────────────────────────────────────────────────────
require('fpdf.php');   // Adjust path if FPDF is in a sub-folder

// ── Database connection constants ─────────────────────────────────────────────
define('DB_HOST', 'localhost');
define('DB_USER', 'student1');
define('DB_PASS', 'pass');
define('DB_NAME', 'Tables_in_baseball_01');

// ── Page layout constants ─────────────────────────────────────────────────────
define('PAGE_ORIENT', 'L');    // L = Landscape  |  P = Portrait
define('PAGE_UNIT',   'mm');
define('PAGE_SIZE',   'Letter');

// ── Colour constants (R, G, B) ────────────────────────────────────────────────
// Header / footer background – dark olive-green (military theme)
define('HDR_R', 44);   define('HDR_G', 74);   define('HDR_B', 44);
// Column-header row – medium olive
define('COL_R', 85);   define('COL_G', 107);  define('COL_B', 47);
// Alternating data row tint – light khaki
define('ALT_R', 240);  define('ALT_G', 238);  define('ALT_B', 215);
// Summary footer row – same dark olive as page header
define('SUM_R', 44);   define('SUM_G', 74);   define('SUM_B', 44);
// White
define('W_R', 255);    define('W_G', 255);    define('W_B', 255);
// Dark text
define('TXT_R', 40);   define('TXT_G', 40);   define('TXT_B', 40);

// ── Column definitions  [ label, width_mm, alignment ] ───────────────────────
$columns = [
    ['ID',          14, 'C'],
    ['First Name',  34, 'L'],
    ['Last Name',   34, 'L'],
    ['Rank',        30, 'C'],
    ['Kills',       20, 'C'],
    ['Deaths',      22, 'C'],
    ['Status',      24, 'C'],
];

// ── Dataset (mirrors SELECT * FROM aliens_marines) ────────────────────────────
// In production this array is replaced by a MySQLi fetch loop, e.g.:
//
//   $conn   = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
//   $result = $conn->query(
//       "SELECT marine_id, first_name, last_name, marine_rank,
//               kills, deaths, status
//        FROM   aliens_marines ORDER BY marine_id ASC"
//   );
//   while ($row = $result->fetch_row()) { $marines[] = $row; }
//
$marines = [
    [1, 'Dwayne',  'Hicks',    'Corporal',   12,  0, 'Alive'],
    [2, 'Jenette', 'Vasquez',  'Private',    18,  0, 'KIA'],
    [3, 'William', 'Hudson',   'Private',     7,  0, 'KIA'],
    [4, 'Mark',    'Drake',    'Private',    10,  0, 'KIA'],
    [5, 'Al',      'Apone',    'Sergeant',    5,  0, 'KIA'],
    [6, 'Scott',   'Gorman',   'Lieutenant',  2,  0, 'KIA'],
    [7, 'Bishop',  'Bishop',   'Synthetic',   0,  0, 'Alive'],
    [8, 'Ellen',   'Ripley',   'Civilian',   15,  0, 'Alive'],
    [9, 'Monica',  'Anderson', 'Commander',   0,  0, 'Alive'],
];

// ════════════════════════════════════════════════════════════════════════════
// Extended PDF class – custom Header and Footer
// ════════════════════════════════════════════════════════════════════════════

/**
 * Class PDF
 *
 * Extends FPDF to provide a military-themed page header and footer that
 * repeat automatically on every page of the document.
 */
class PDF extends FPDF
{
    /**
     * Header()
     * Called automatically by FPDF at the top of each new page.
     * Renders a dark-green banner with the report title and subtitle.
     */
    function Header()
    {
        // Dark-green background banner
        $this->SetFillColor(HDR_R, HDR_G, HDR_B);
        $this->Rect(0, 0, $this->GetPageWidth(), 24, 'F');

        // Main title – white bold
        $this->SetFont('Arial', 'B', 16);
        $this->SetTextColor(W_R, W_G, W_B);
        $this->SetY(4);
        $this->Cell(0, 8, 'USCM Colonial Marine Personnel Report', 0, 1, 'C');

        // Subtitle – white italic
        $this->SetFont('Arial', 'I', 10);
        $this->Cell(0, 6,
            "Database: aliens_marines  |  Operation: Hadley's Hope  |  Generated: "
            . date('F j, Y'),
            0, 1, 'C');

        // Reset text colour for body content
        $this->SetTextColor(TXT_R, TXT_G, TXT_B);
        $this->SetY(30);
    }

    /**
     * Footer()
     * Called automatically by FPDF at the bottom of each page.
     * Renders a dark-green banner with a classification notice and page number.
     */
    function Footer()
    {
        $this->SetY(-15);

        // Dark-green background banner
        $this->SetFillColor(HDR_R, HDR_G, HDR_B);
        $this->Rect(0, $this->GetY() - 2, $this->GetPageWidth(), 20, 'F');

        // Left: classification notice
        $this->SetFont('Arial', 'I', 9);
        $this->SetTextColor(W_R, W_G, W_B);
        $this->Cell(0, 8, 'CLASSIFIED  -  Weyland-Yutani Corporation / USCM Joint Command', 0, 0, 'L');

        // Right: page x of {nb} (nb is set by AliasNbPages)
        $this->Cell(0, 8, 'Page ' . $this->PageNo() . ' of {nb}', 0, 0, 'R');

        $this->SetTextColor(TXT_R, TXT_G, TXT_B);
    }
}

// ════════════════════════════════════════════════════════════════════════════
// Helper functions
// ════════════════════════════════════════════════════════════════════════════

/**
 * drawColumnHeaders()
 * Renders the styled column-header row for the marines data table.
 *
 * @param PDF   $pdf      Active PDF instance
 * @param array $columns  Column definition array
 */
function drawColumnHeaders(PDF $pdf, array $columns): void
{
    $pdf->SetFillColor(COL_R, COL_G, COL_B);      // Olive green
    $pdf->SetTextColor(W_R, W_G, W_B);
    $pdf->SetFont('Arial', 'B', 9);
    $pdf->SetDrawColor(180, 180, 160);

    foreach ($columns as $col) {
        $pdf->Cell($col[1], 8, $col[0], 1, 0, 'C', true);
    }
    $pdf->Ln();

    // Reset for data rows
    $pdf->SetTextColor(TXT_R, TXT_G, TXT_B);
    $pdf->SetFont('Arial', '', 9);
}

/**
 * drawDataRows()
 * Renders one row per marine with alternating row shading.
 * Triggers a new page and re-draws column headers if vertical space runs out.
 *
 * @param PDF   $pdf      Active PDF instance
 * @param array $marines  Marine records array
 * @param array $columns  Column definition array
 */
function drawDataRows(PDF $pdf, array $marines, array $columns): void
{
    foreach ($marines as $i => $m) {
        // New page if too close to bottom
        if ($pdf->GetY() > ($pdf->GetPageHeight() - 25)) {
            $pdf->AddPage();
            drawColumnHeaders($pdf, $columns);
        }

        // Alternating row background
        if ($i % 2 === 0) {
            $pdf->SetFillColor(W_R, W_G, W_B);
        } else {
            $pdf->SetFillColor(ALT_R, ALT_G, ALT_B);
        }

        $pdf->Cell($columns[0][1], 7, $m[0], 1, 0, $columns[0][2], true); // ID
        $pdf->Cell($columns[1][1], 7, $m[1], 1, 0, $columns[1][2], true); // First Name
        $pdf->Cell($columns[2][1], 7, $m[2], 1, 0, $columns[2][2], true); // Last Name
        $pdf->Cell($columns[3][1], 7, $m[3], 1, 0, $columns[3][2], true); // Rank
        $pdf->Cell($columns[4][1], 7, $m[4], 1, 0, $columns[4][2], true); // Kills
        $pdf->Cell($columns[5][1], 7, $m[5], 1, 0, $columns[5][2], true); // Deaths
        $pdf->Cell($columns[6][1], 7, $m[6], 1, 0, $columns[6][2], true); // Status
        $pdf->Ln();
    }
}

/**
 * drawSummaryFooter()
 * Renders a dark-olive summary row beneath the data table showing
 * total records, combined kills, and survivor count.
 *
 * @param PDF   $pdf      Active PDF instance
 * @param array $marines  Marine records array
 * @param array $columns  Column definition array
 */
function drawSummaryFooter(PDF $pdf, array $marines, array $columns): void
{
    $totalKills   = array_sum(array_column($marines, 4));
    $totalDeaths  = array_sum(array_column($marines, 5));
    $totalRecords = count($marines);
    $survivors    = count(array_filter($marines, fn($m) => $m[6] === 'Alive'));

    $pdf->SetFillColor(SUM_R, SUM_G, SUM_B);
    $pdf->SetTextColor(W_R, W_G, W_B);
    $pdf->SetFont('Arial', 'B', 9);

    // Span first four columns for label
    $spanW = $columns[0][1] + $columns[1][1] + $columns[2][1] + $columns[3][1];
    $pdf->Cell($spanW,          7, 'Records: ' . $totalRecords . '   |   Survivors: ' . $survivors,
                1, 0, 'R', true);
    $pdf->Cell($columns[4][1], 7, $totalKills,  1, 0, 'C', true); // Total kills
    $pdf->Cell($columns[5][1], 7, $totalDeaths, 1, 0, 'C', true); // Total deaths
    $pdf->Cell($columns[6][1], 7, '',            1, 0, 'C', true);
    $pdf->Ln();

    $pdf->SetTextColor(TXT_R, TXT_G, TXT_B);
}

// ════════════════════════════════════════════════════════════════════════════
// Build the PDF document
// ════════════════════════════════════════════════════════════════════════════

$pdf = new PDF(PAGE_ORIENT, PAGE_UNIT, PAGE_SIZE);
$pdf->AliasNbPages();                     // Enables {nb} token in Footer
$pdf->SetAuthor('Zachary');
$pdf->SetTitle('USCM Colonial Marine Personnel Report');
$pdf->SetSubject('Module 8 – aliens_marines table');
$pdf->SetMargins(12, 38, 12);           // Left, Top, Right  (top leaves header room)
$pdf->SetAutoPageBreak(true, 20);

// ── PAGE 1: General Information ───────────────────────────────────────────────
$pdf->AddPage();

// Section heading
$pdf->SetFont('Arial', 'B', 13);
$pdf->SetTextColor(HDR_R, HDR_G, HDR_B);
$pdf->Cell(0, 8, 'Mission Background & Database Overview', 0, 1, 'L');
$pdf->SetTextColor(TXT_R, TXT_G, TXT_B);

// Horizontal rule
$pdf->SetDrawColor(COL_R, COL_G, COL_B);
$pdf->SetLineWidth(0.5);
$pdf->Line($pdf->GetX(), $pdf->GetY(), $pdf->GetPageWidth() - 12, $pdf->GetY());
$pdf->Ln(4);

// Introduction paragraph
$pdf->SetFont('Arial', '', 10);
$intro  = 'In 2179, the United States Colonial Marine Corps (USCM) dispatched a squad aboard the ';
$intro .= 'USS Sulaco to investigate the loss of contact with the terraforming colony on LV-426 ';
$intro .= "(Hadley's Hope). The mission, overseen by Weyland-Yutani Corporation, resulted in heavy ";
$intro .= 'casualties caused by an infestation of Xenomorph aliens. This report documents all ';
$intro .= 'personnel assigned to the operation, drawn from the aliens_marines table in the course ';
$intro .= 'database. Records include rank, confirmed alien kills, and final mission status (Alive / KIA).';
$pdf->MultiCell(0, 6, $intro, 0, 'J');
$pdf->Ln(5);

// ── Database info key-value table ─────────────────────────────────────────────
$pdf->SetFont('Arial', 'B', 11);
$pdf->SetTextColor(HDR_R, HDR_G, HDR_B);
$pdf->Cell(0, 7, 'Database Information', 0, 1, 'L');
$pdf->SetTextColor(TXT_R, TXT_G, TXT_B);
$pdf->Ln(1);

$totalKills = array_sum(array_column($marines, 4));
$survivors  = count(array_filter($marines, fn($m) => $m[6] === 'Alive'));
$kia        = count($marines) - $survivors;
$ranks      = implode(', ', array_unique(array_column($marines, 3)));

$infoRows = [
    ['Database',            'Tables_in_baseball_01'],
    ['Table',               'aliens_marines'],
    ['Total Personnel',     count($marines) . ' marines'],
    ['Confirmed Kills',     $totalKills . ' alien kills (combined)'],
    ['Survivors',           $survivors . ' personnel'],
    ['KIA',                 $kia . ' personnel'],
    ['Ranks Represented',   $ranks],
    ['Report Date',         date('F j, Y')],
];

$pdf->SetFont('Arial', '', 10);
foreach ($infoRows as $idx => $row) {
    $fill = ($idx % 2 === 0);
    $pdf->SetFillColor($fill ? ALT_R : 255, $fill ? ALT_G : 255, $fill ? ALT_B : 255);
    $pdf->Cell(55,  7, $row[0] . ':', 1, 0, 'R', true);
    $pdf->Cell(185, 7, $row[1],        1, 1, 'L', true);
}
$pdf->Ln(6);

// ── Table schema section ──────────────────────────────────────────────────────
$pdf->SetFont('Arial', 'B', 11);
$pdf->SetTextColor(HDR_R, HDR_G, HDR_B);
$pdf->Cell(0, 7, 'Table Schema - aliens_marines', 0, 1, 'L');
$pdf->SetTextColor(TXT_R, TXT_G, TXT_B);
$pdf->Ln(1);



$schemaCols = [['Field', 45], ['Type', 40], ['Description', 155]];
$schemaRows = [
    ['marine_id',   'INT (PK, AUTO)',  'Unique numeric identifier for each marine record.'],
    ['first_name',  'VARCHAR(50)',     "Marine's given name."],
    ['last_name',   'VARCHAR(50)',     "Marine's surname."],
    ['marine_rank', 'VARCHAR(30)',     'Military rank or classification (Corporal, Private, etc.).'],
    ['kills',       'INT',             'Number of confirmed alien kills during the operation.'],
    ['deaths',      'INT',             'Number of times the marine was killed (reserved field).'],
    ['status',      'VARCHAR(20)',     'Mission outcome: Alive or KIA (Killed In Action).'],
];

// Schema header row
$pdf->SetFillColor(COL_R, COL_G, COL_B);
$pdf->SetTextColor(W_R, W_G, W_B);
$pdf->SetFont('Arial', 'B', 9);
foreach ($schemaCols as $sc) {
    $pdf->Cell($sc[1], 7, $sc[0], 1, 0, 'C', true);
}
$pdf->Ln();

// Schema data rows
$pdf->SetFont('Arial', '', 9);
foreach ($schemaRows as $si => $sr) {
    $fill = ($si % 2 === 0);
    $pdf->SetFillColor($fill ? 255 : ALT_R, $fill ? 255 : ALT_G, $fill ? 255 : ALT_B);
    $pdf->SetTextColor(TXT_R, TXT_G, TXT_B);
    $pdf->Cell($schemaCols[0][1], 6, $sr[0], 1, 0, 'L', true);
    $pdf->Cell($schemaCols[1][1], 6, $sr[1], 1, 0, 'L', true);
    $pdf->Cell($schemaCols[2][1], 6, $sr[2], 1, 1, 'L', true);
}
$pdf->Ln(6);

// ── SQL query block ───────────────────────────────────────────────────────────
$pdf->SetFont('Arial', 'B', 11);
$pdf->SetTextColor(HDR_R, HDR_G, HDR_B);
$pdf->Cell(0, 7, 'SQL Query Used to Retrieve Data', 0, 1, 'L');
$pdf->SetTextColor(TXT_R, TXT_G, TXT_B);

$pdf->SetFillColor(245, 245, 235);
$pdf->SetFont('Courier', '', 9);
$sqlLines = [
    'SELECT marine_id, first_name, last_name, marine_rank, kills, deaths, status',
    'FROM   aliens_marines',
    'ORDER  BY marine_id ASC;',
];
foreach ($sqlLines as $ln) {
    $pdf->Cell(0, 6, $ln, 0, 1, 'L', true);
}

// ── PAGE 2: Data Table ────────────────────────────────────────────────────────
if ($pdf->GetY() < ($pdf->GetPageHeight() - 60)) {
    $pdf->AddPage();
}

$pdf->SetFont('Arial', 'B', 13);
$pdf->SetTextColor(HDR_R, HDR_G, HDR_B);
$pdf->Cell(0, 8, 'Marine Personnel Data Table', 0, 1, 'L');
$pdf->SetTextColor(TXT_R, TXT_G, TXT_B);
$pdf->SetDrawColor(COL_R, COL_G, COL_B);
$pdf->Line($pdf->GetX(), $pdf->GetY(), $pdf->GetPageWidth() - 12, $pdf->GetY());
$pdf->Ln(4);

drawColumnHeaders($pdf, $columns);
drawDataRows($pdf, $marines, $columns);
drawSummaryFooter($pdf, $marines, $columns);

// ── Stream PDF inline to browser ──────────────────────────────────────────────
// 'I' = open inline in browser   |   'D' = force download
$pdf->Output('I', 'Zachary_PDF.pdf');
?>